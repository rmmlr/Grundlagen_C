/*
$title$

Project: $safeprojectname$
Author:  $username$
Date:    $time$
Repo:    $repo$

Praktikumsaufgabe: Nr.: $exerciseNo$
*/

#include <iostream>

using namespace std;

void main(void)
{
	// Wenn Programm nicht startet (keine Konsolenausgabe) bitte folgende Zeile
	// auskommentieren oder Anwendung mit Administratorrechten neu starten.
	locale::global(locale("German_germany"));


	//Variablendeklaration




	//Ausgabekopf
	cout << "$title$" << endl;
	cout << "Praktikumsaufgabe: Nr.: $exerciseNo$ (Projekt: $safeprojectname$)" << endl << endl;



	//Work




	//Programmende
	cout << endl << endl;
	system("pause");
}